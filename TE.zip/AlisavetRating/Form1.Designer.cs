﻿namespace AlisavetRating
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.просмотретьОценкиВрачейToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьВрачаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.findBtn = new System.Windows.Forms.Button();
            this.findBox = new System.Windows.Forms.TextBox();
            this.showGridView = new System.Windows.Forms.DataGridView();
            this.showRateBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.filialBox = new System.Windows.Forms.ComboBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.просмотретьОценкиВрачейToolStripMenuItem,
            this.добавитьВрачаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(827, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // просмотретьОценкиВрачейToolStripMenuItem
            // 
            this.просмотретьОценкиВрачейToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.просмотретьОценкиВрачейToolStripMenuItem.Name = "просмотретьОценкиВрачейToolStripMenuItem";
            this.просмотретьОценкиВрачейToolStripMenuItem.Size = new System.Drawing.Size(225, 24);
            this.просмотретьОценкиВрачейToolStripMenuItem.Text = "Просмотреть оценки врачей";
            this.просмотретьОценкиВрачейToolStripMenuItem.Click += new System.EventHandler(this.просмотретьОценкиВрачейToolStripMenuItem_Click);
            // 
            // добавитьВрачаToolStripMenuItem
            // 
            this.добавитьВрачаToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.добавитьВрачаToolStripMenuItem.Name = "добавитьВрачаToolStripMenuItem";
            this.добавитьВрачаToolStripMenuItem.Size = new System.Drawing.Size(135, 24);
            this.добавитьВрачаToolStripMenuItem.Text = "Добавить врача";
            this.добавитьВрачаToolStripMenuItem.Click += new System.EventHandler(this.добавитьВрачаToolStripMenuItem_Click);
            // 
            // findBtn
            // 
            this.findBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.findBtn.Location = new System.Drawing.Point(711, 45);
            this.findBtn.Margin = new System.Windows.Forms.Padding(4);
            this.findBtn.Name = "findBtn";
            this.findBtn.Size = new System.Drawing.Size(100, 25);
            this.findBtn.TabIndex = 1;
            this.findBtn.Text = "Найти";
            this.findBtn.UseVisualStyleBackColor = true;
            this.findBtn.Click += new System.EventHandler(this.findBtn_Click);
            // 
            // findBox
            // 
            this.findBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.findBox.Location = new System.Drawing.Point(419, 48);
            this.findBox.Margin = new System.Windows.Forms.Padding(4);
            this.findBox.Name = "findBox";
            this.findBox.Size = new System.Drawing.Size(255, 22);
            this.findBox.TabIndex = 2;
            this.findBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.findBox_KeyUp);
            // 
            // showGridView
            // 
            this.showGridView.AllowUserToAddRows = false;
            this.showGridView.AllowUserToDeleteRows = false;
            this.showGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.showGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.showGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.showGridView.Location = new System.Drawing.Point(16, 94);
            this.showGridView.Margin = new System.Windows.Forms.Padding(4);
            this.showGridView.MultiSelect = false;
            this.showGridView.Name = "showGridView";
            this.showGridView.ReadOnly = true;
            this.showGridView.RowHeadersVisible = false;
            this.showGridView.RowHeadersWidth = 51;
            this.showGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.showGridView.Size = new System.Drawing.Size(795, 255);
            this.showGridView.TabIndex = 3;
            // 
            // showRateBtn
            // 
            this.showRateBtn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.showRateBtn.Location = new System.Drawing.Point(16, 373);
            this.showRateBtn.Margin = new System.Windows.Forms.Padding(4);
            this.showRateBtn.Name = "showRateBtn";
            this.showRateBtn.Size = new System.Drawing.Size(795, 47);
            this.showRateBtn.TabIndex = 4;
            this.showRateBtn.Text = "Вывести на оценивающее устройство";
            this.showRateBtn.UseVisualStyleBackColor = true;
            this.showRateBtn.Click += new System.EventHandler(this.showRateBtn_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(676, 45);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(27, 25);
            this.button1.TabIndex = 5;
            this.button1.Text = "Х";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 53);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Текущий филиал:";
            // 
            // filialBox
            // 
            this.filialBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.filialBox.FormattingEnabled = true;
            this.filialBox.Location = new System.Drawing.Point(152, 47);
            this.filialBox.Margin = new System.Windows.Forms.Padding(4);
            this.filialBox.Name = "filialBox";
            this.filialBox.Size = new System.Drawing.Size(175, 24);
            this.filialBox.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(827, 446);
            this.Controls.Add(this.filialBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.showRateBtn);
            this.Controls.Add(this.showGridView);
            this.Controls.Add(this.findBox);
            this.Controls.Add(this.findBtn);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(767, 481);
            this.Name = "Form1";
            this.Text = "Вывести оценивание врача";
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.showGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem просмотретьОценкиВрачейToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьВрачаToolStripMenuItem;
        private System.Windows.Forms.Button findBtn;
        private System.Windows.Forms.TextBox findBox;
        private System.Windows.Forms.Button showRateBtn;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.DataGridView showGridView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox filialBox;
    }
}

