﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlisavetRating
{
    public partial class FormAddDoctor : Form
    {
        string filename, format;
        byte[] imageData;
        SqlCommand sqlCommand;
        SqlConnection connection;
        bool photo = false;
        public FormAddDoctor()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Изображение (*.png;*.jpg)|*.png;*.jpg";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    filename = openFileDialog.FileName;
                    format = filename.Split('.').Last();
                    using (FileStream fs = new FileStream(filename, FileMode.Open))
                    {
                        imageData = new byte[fs.Length];
                        fs.Read(imageData, 0, imageData.Length);
                    }
                }
                pictureBox1.Image = ByteToImage(imageData);
                photo = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool fieldsFilled = true;
            surnameLabel.Text = "";
            nameLabel.Text = "";
            if (string.IsNullOrWhiteSpace(surnameBox.Text))
            {
                surnameLabel.Text = "Заполните фамилию";
                fieldsFilled = false;
            }
            if (string.IsNullOrWhiteSpace(nameBox.Text))
            {
                nameLabel.Text = "Заполните имя";
                fieldsFilled = false;
            }
            if (fieldsFilled)
            {
                if (photo && checkBox1.Checked)
                {
                    sqlCommand = new SqlCommand();
                    sqlCommand.CommandText = @"INSERT INTO [dbo].[Images] VALUES (@Image, @Format)";
                    sqlCommand.Parameters.Add("@Image", SqlDbType.Image, 1000000);
                    sqlCommand.Parameters.Add("@Format", SqlDbType.NVarChar, 30);
                    sqlCommand.Parameters["@Image"].Value = imageData;
                    sqlCommand.Parameters["@Format"].Value = format;
                    connection = new SqlConnection(DBHelper.connectionString);
                    try
                    {
                        connection.Open();
                        sqlCommand.Connection = connection;
                        sqlCommand.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Ошибка");
                    }
                    finally
                    {
                        connection.Close();
                    }
                    string imageId = DBHelper.CmdScalar("SELECT max(ID_Image) FROM [dbo].[Images]");
                    DBHelper.CmdScalar($"INSERT INTO [dbo].[Employee] (Surname, Name, MiddleName, Image_ID, Description) VALUES ('{surnameBox.Text}', '{nameBox.Text}', '{middlenameBox.Text}', {imageId}, '{descriptionBox.Text}')");
                }
                else DBHelper.CmdScalar($"INSERT INTO [dbo].[Employee] (Surname, Name, MiddleName, Description) VALUES ('{surnameBox.Text}', '{nameBox.Text}', '{middlenameBox.Text}', '{descriptionBox.Text}')");
                FormAdd form = Owner as FormAdd;
                form.showGridView.DataSource = DBHelper.FillDataSet("SELECT * FROM [dbo].[Employee_show]").Tables[0];
                form.showGridView.Columns[0].Visible = false;
                Close();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                pictureBox1.Enabled = true;
                photoButton.Enabled = true;
            }
            else
            {
                pictureBox1.Enabled = false;
                photoButton.Enabled = false;
            }
        }

        public static Bitmap ByteToImage(byte[] blob)
        {
            MemoryStream mStream = new MemoryStream();
            byte[] pData = blob;
            mStream.Write(pData, 0, Convert.ToInt32(pData.Length));
            Bitmap bm = new Bitmap(mStream, false);
            mStream.Dispose();
            return bm;
        }
    }
}
