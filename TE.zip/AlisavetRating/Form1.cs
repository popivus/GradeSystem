﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlisavetRating
{
    public partial class Form1 : Form
    {
        private static string path = $"{Environment.CurrentDirectory}//connectionstring.txt";
        private static StreamReader sr = new StreamReader(path, System.Text.Encoding.Default);
        private static string ip = (sr.ReadLine());
        private static int port = 5000;
        public Form1()
        {
            InitializeComponent();
        }

        private void просмотретьОценкиВрачейToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormShowRating form = new FormShowRating();
            form.ShowDialog();
        }

        private void добавитьВрачаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAdd form = new FormAdd();
            form.Owner = this;
            form.ShowDialog();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            showGridView.DataSource = DBHelper.FillDataSet("SELECT * FROM Employee_show").Tables[0];
            showGridView.Columns[0].Visible = false;
            filialBox.DataSource = DBHelper.FillDataSet("SELECT * FROM Branch").Tables[0];
            filialBox.DisplayMember = "Name";
            filialBox.ValueMember = "ID_Branch";
        }

        private void findBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(findBox.Text))
            {
                showGridView.DataSource = DBHelper.FillDataSet($"SELECT * FROM Employee_show WHERE Фамилия like '%{findBox.Text}%' or Имя like '%{findBox.Text}%' or Отчество like '%{findBox.Text}%' or" +
                    $" Фамилия + ' ' + Имя like '%{findBox.Text}%' or Имя + ' ' + Фамилия like '%{findBox.Text}%' or Имя + ' ' + Отчество like '%{findBox.Text}%' " +
                    $"or Фамилия + ' ' + Имя + ' ' + Отчество like '%{findBox.Text}%' or Имя + ' ' + Отчество + ' ' + Фамилия like '%{findBox.Text}%'").Tables[0];
                showGridView.Columns[0].Visible = false;
            }
            else
            {
                showGridView.DataSource = DBHelper.FillDataSet("SELECT * FROM Employee_show").Tables[0];
                showGridView.Columns[0].Visible = false;
            }
        }

        private void findBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (!string.IsNullOrWhiteSpace(findBox.Text))
                {
                    showGridView.DataSource = DBHelper.FillDataSet($"SELECT * FROM Employee_show WHERE Фамилия like '%{findBox.Text}%' or Имя like '%{findBox.Text}%' or Отчество like '%{findBox.Text}%' or" +
                        $" Фамилия + ' ' + Имя like '%{findBox.Text}%' or Имя + ' ' + Фамилия like '%{findBox.Text}%' or Имя + ' ' + Отчество like '%{findBox.Text}%' " +
                        $"or Фамилия + ' ' + Имя + ' ' + Отчество like '%{findBox.Text}%' or Имя + ' ' + Отчество + ' ' + Фамилия like '%{findBox.Text}%'").Tables[0];
                    showGridView.Columns[0].Visible = false;
                }
                else
                {
                    showGridView.DataSource = DBHelper.FillDataSet("SELECT * FROM Employee_show").Tables[0];
                    showGridView.Columns[0].Visible = false;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            showGridView.DataSource = DBHelper.FillDataSet("SELECT * FROM Employee_show").Tables[0];
            showGridView.Columns[0].Visible = false;
            findBox.Text = "";
        }

        private void showRateBtn_Click(object sender, EventArgs e)
        {
                //MessageBox.Show($"{showGridView.SelectedRows[0].Cells[2].Value.ToString()} {showGridView.SelectedRows[0].Cells[1].Value.ToString()}");
                string finalRate = null;
                var tspEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);
                var tspSocket = new System.Net.Sockets.Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                tspSocket.Bind(tspEndPoint);
                tspSocket.Listen(5);
                ImageConverter _imageConverter = new ImageConverter();
                //MessageBox.Show(showGridView.SelectedRows[0].Cells[0].Value.ToString());
                byte[] pic = (byte[])_imageConverter.ConvertTo(DBHelper.CmdImg($"SELECT Image FROM Images WHERE ID_Image = {showGridView.SelectedRows[0].Cells[0].Value.ToString()}"), typeof(byte[]));
                // MessageBox.Show(pic.Length.ToString());
                int countBytes = 0;
                int saveCountBytes = 0;
                while (true)
                {
                    var listener = tspSocket.Accept();
                    var buffer = new byte[256];
                    var size = 0;
                    var data = new StringBuilder();
                    do
                    {
                        size = listener.Receive(buffer);
                        data.Append(Encoding.UTF8.GetString(buffer, 0, size));
                    }
                    while (listener.Available > 0);
                    if ($"{data}" == "Connect")
                    {
                        listener.Send(Encoding.UTF8.GetBytes("Connected"));
                    }

                    if ($"{data}" == "GO")
                    {
                        string sizeImage = pic.Length.ToString();
                        for (int i = pic.Length.ToString().Length; i < 10; i++)
                        {
                            sizeImage = "0" + sizeImage;
                        }
                        listener.Send(Encoding.UTF8.GetBytes(sizeImage));
                    }

                    int muchBytes = 1024;

                    if ($"{data}" == "IMAGE")
                    {
                        byte[] part = new byte[muchBytes];

                        for (int i = 0; i < muchBytes && countBytes < pic.Length; i++)
                        {
                            part[i] = pic[countBytes];
                            countBytes++;
                        }

                        listener.Send(part);
                    }
                    else if ($"{data}" == "ERRORIMAGE")
                    {
                        countBytes = saveCountBytes;

                        byte[] part = new byte[muchBytes];

                        for (int i = 0; i < muchBytes && countBytes < pic.Length; i++)
                        {
                            part[i] = pic[countBytes];
                            countBytes++;
                        }

                        listener.Send(part);
                    }
                    else if ($"{data}" == "getText")
                    {
                        listener.Send(Encoding.UTF8.GetBytes($"{showGridView.SelectedRows[0].Cells[2].Value.ToString()} {showGridView.SelectedRows[0].Cells[1].Value.ToString()}"));
                    }
                    switch ($"{data}")
                    {
                        case "1.0":
                            finalRate = $"{data}";
                            break;
                        case "2.0":
                            finalRate = $"{data}";
                            break;
                        case "3.0":
                            finalRate = $"{data}";
                            break;
                        case "4.0":
                            finalRate = $"{data}";
                            break;
                        case "5.0":
                            finalRate = $"{data}";
                            break;
                        case "6.0":
                            finalRate = $"{data}";
                            break;
                        case "7.0":
                            finalRate = $"{data}";
                            break;
                        case "8.0":
                            finalRate = $"{data}";
                            break;
                        case "9.0":
                            finalRate = $"{data}";
                            break;
                        case "10.0":
                            finalRate = $"{data}";
                            break;
                    }
                    if (finalRate != null)
                {
                    MessageBox.Show(finalRate, "Поставленная оценка");
                    SqlCommand sqlCommand = new SqlCommand();
                        SqlConnection connection = new SqlConnection(DBHelper.connectionString);
                        try
                        {
                            connection.Open();
                            sqlCommand = new SqlCommand($"INSERT INTO [dbo].[Rates] (Employee_ID, Branch_ID, ReceiptDate, Rate) VALUES ({showGridView.SelectedRows[0].Cells[0].Value.ToString()}, {filialBox.SelectedValue}, '{DateTime.Now.ToString()}', {finalRate})", connection);
                            sqlCommand.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Ошибка");
                        }
                        finally
                        {
                            connection.Close();
                        }
                        data = null;
                        listener.Send(Encoding.UTF8.GetBytes("Received"));
                    finalRate = null;
                    listener.Shutdown(SocketShutdown.Both);
                        listener.Close();
                        break;
                    }
                    saveCountBytes = countBytes;
                listener.Shutdown(SocketShutdown.Both);
                    listener.Close();
                
                }
            tspSocket.Close();
        } 
    }
}