﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlisavetRating
{
    public partial class FormAdd : Form
    {
        public FormAdd()
        {
            InitializeComponent();
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            FormAddDoctor form = new FormAddDoctor();
            form.Owner = this;
            form.ShowDialog();
        }

        private void editBtn_Click(object sender, EventArgs e)
        {
            if (showGridView.SelectedRows.Count != 0)
            {
                FormEditDoctor form = new FormEditDoctor();
                form.Owner = this;
                form.ShowDialog();
            }
        }

        private void FormAdd_Load(object sender, EventArgs e)
        {
            showGridView.DataSource = DBHelper.FillDataSet("SELECT * FROM [dbo].[Employee_show]").Tables[0];
            showGridView.Columns[0].Visible = false;
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (showGridView.SelectedRows.Count != 0)
            {
                Form1 form = Owner as Form1;
                DBHelper.CmdScalar($"DELETE FROM [Employee] WHERE [ID_Employee] = {showGridView.SelectedRows[0].Cells[0].Value}");
                showGridView.DataSource = DBHelper.FillDataSet("SELECT * FROM [dbo].[Employee_show]").Tables[0];
                showGridView.Columns[0].Visible = false;
                form.showGridView.DataSource = DBHelper.FillDataSet("SELECT * FROM [dbo].[Employee_show]").Tables[0];
                form.showGridView.Columns[0].Visible = false;
            }
        }

        private void showGridView_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            Form1 form = Owner as Form1;
            form.showGridView.DataSource = DBHelper.FillDataSet("SELECT * FROM [dbo].[Employee_show]").Tables[0];
            form.showGridView.Columns[0].Visible = false;
        }
    }
}
